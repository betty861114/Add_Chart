const productList=document.querySelector(".productWrap");
const productSelect=document.querySelector(".productSelect");
const cartList=document.querySelector('.shoppingCart-tableList');
let productData=[];
let cartData=[];
function init(){
    getProductList();
    getCartList();
}
init();
function getProductList(){
    axios.get(`https://livejs-api.hexschool.io/api/livejs/v1/customer/${apiPath}/products`)
    .then(function(res){
        productData=res.data.products;
        renderProduct();
    })
}
//把重複的程式獨立出來
function combineProductHTML(item){
    return `<li class="productCard">
    <h4 class="productType">新品</h4>
    <img src="${item.images}" alt="">
    <a href="#" class="addCardBtn js-addCart" data-id="${item.id}">加入購物車</a>
    <h3>${item.title}</h3>
    <del class="originPrice">NT${item.origin_price}</del>
    <p class="nowPrice">NT${item.price}</p>
    </li>`;
}
//列出所有商品
function renderProduct(){
    let str="";
        productData.forEach(function(item){
            str+= combineProductHTML(item);
        })
        productList.innerHTML=str;
}
//依照分類列出
productSelect.addEventListener('change',function(e){
    const category=e.target.value;
    if(category=="全部"){
        renderProduct();
        return;
    }
    let str="";
    productData.forEach(function(item){
        if(item.category==category){
            str+=combineProductHTML(item);
        }
    })
    productList.innerHTML=str;
})
//加入購物車
productList.addEventListener('click',function(e){
    e.preventDefault(); //取消預設值
    let productId=e.target.getAttribute("data-id");
    console.log(productId);
    let numCkeck=1;
    cartData.forEach(function(item){
        if(item.product.id===productId){
            numCkeck=item.quantity+=1;
        }
    })
    axios.post(`https://livejs-api.hexschool.io/api/livejs/v1/customer/${apiPath}/carts`,{
        "data": {
            "productId": productId,
            "quantity": numCkeck
          }
    }).then(function(res){
        alert("加入購物車");
        getCartList();
    })

    let addCartClass = e.target.getAttribute("class");
    if(addCartClass!=="addCardBtn"){
        return;
    }
    
    
})
//取得購物車列表
function getCartList(){
    axios.get(`https://livejs-api.hexschool.io/api/livejs/v1/customer/${apiPath}/carts`)
    .then(function(res){
        document.querySelector('.js-total').textContent=res.data.finalTotal;
        cartData=res.data.carts;
        let str="";
        cartData.forEach(function(item){
            str+=`<tr>
            <td>
                <div class="cardItem-title">
                    <img src="${item.product.images}" alt="">
                    <p>${item.product.title}</p>
                </div>
            </td>
            <td>NT${item.product.price}</td>
            <td>${item.quantity}</td>
            <td>NT$${item.product.price*item.quantity}</td>
            <td class="discardBtn">
                <a href="#" class="material-icons" data-id=${item.id}>
                    clear
                </a>
            </td>
        </tr>`;
        
        })
        
        cartList.innerHTML=str;
    })
}
//刪除品項
cartList.addEventListener('click',function(e){
    e.preventDefault();
    const cartId =e.target.getAttribute("data-id");
    axios.delete(`https://livejs-api.hexschool.io/api/livejs/v1/customer/${apiPath}/carts/${cartId}`)
    .then(function(res){
        alert("刪除單筆購物車成功～！")
        getCartList();
    })
    if(cartId==null){
        alert("點錯地方囉～");
        return;
    }
})
//清空購物車
const discardAllBtn = document.querySelector('.discardAllBtn');
discardAllBtn.addEventListener('click',function(e){
    e.preventDefault();
    axios.delete(`https://livejs-api.hexschool.io/api/livejs/v1/customer/${apiPath}/carts`)
    .then(function(res){
        alert("清空購物車");
        getCartList();
    })
    .catch(function(res){
        alert("購物車已清空！");
    })
})

//送出訂單
const orderInfoBtn = document.querySelector('.orderInfo-btn');
orderInfoBtn.addEventListener('click',function(e){
    e.preventDefault();
    if(cartData.length==0){
        alert("請先新增商品");
        return;
    }
    const customerName=document.querySelector("#customerName").value;
    const customerPhone=document.querySelector("#customerPhone").value;
    const customerEmail=document.querySelector("#customerEmail").value;
    const customerAddress=document.querySelector("#customerAddress").value;
    const tradeWay=document.querySelector("#tradeWay").value;
    if(customerName==''||customerPhone==''||customerEmail==''|customerAddress==''|tradeWay==''){
        alert("請輸入訂單資訊");
        return;
    }
    axios.post(`https://livejs-api.hexschool.io/api/livejs/v1/customer/${apiPath}/orders`,{
    "data": {
        "user": {
          "name": customerName,
          "tel": customerPhone,
          "email": customerEmail,
          "address": customerAddress,
          "payment": tradeWay
        }
      }
    }).then(function(res){
        alert("訂單建立成功");
        //清空資料
        document.querySelector("#customerName").value="";
        document.querySelector("#customerPhone").value="";
        document.querySelector("#customerEmail").value="";
        document.querySelector("#customerAddress").value="";
        document.querySelector("#tradeWay").value="ATM";
        getCartList();
    })
})